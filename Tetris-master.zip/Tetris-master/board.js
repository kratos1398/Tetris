class board {
    constructor(w, h) {
        this.height = h;
        this.width = w;
        this.blocks = [];
        this.blockHeight = 0;
        this.currentBlock = -4;
    }
    show() {
        line(50, 50, this.width - 50, 50);
        line(50, 50, 50, this.height - 50);
        line(50, this.height - 50, this.width - 50, this.height - 50);
        line(this.width - 50, 50, this.width - 50, this.height - 50);
        stroke(255);


        for (let i = 0; i < this.blocks.length; i++) {
            this.blocks[i].bShow();
        }
    }
    move() {
        if (this.blocks.length != 0) {

            this.checkPos(this.blocks[this.currentBlock]);
            if (this.blockHeight < this.height - 60) {
                console.log(this.blockHeight)
                this.blockHeight = this.blocks[this.currentBlock].changePos();
                if (this.blockHeight >= this.height - 60) {
                    //this.blocks[this.currentBlock].yPos = this.height - 60;
                    this.shapes();
                }
            }
        } else {
            this.shapes();
        }

    }
    checkPos(bk) {
        for (let i = 0; i < this.blocks.length - 1; i++) {
            if (bk.xPos === this.blocks[i].xPos && bk.yPos === this.blocks[i].yPos - 10) {

                this.shapes();

            }


        }
    }
    shapes() {

        this.currentBlock += 1;
        this.blocks[this.currentBlock] = new block(100, 100 + (10));
        this.blockHeight = 0;

    }
}
