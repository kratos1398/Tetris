class block {
    constructor(x, y) {
        this.xPos = x;
        this.yPos = y;
        this.height = 10;
        this.width = 10;
        this.ySpeed = 10;
    }
    bShow() {
        rect(this.xPos, this.yPos, this.width, this.height);
        fill(255);

    }
    changePos() {
        this.yPos += this.ySpeed
        return this.yPos;
    }
    changeXPos(right) {
        if (right) {
            this.xPos += 10;

        } else {
            this.xPos -= 10;
        }
    }
    increase() {
        this.ySpeed += 10;
    }
    returnSpeed() {
        this.ySpeed = 10;
    }
}
