let x = 40;
let y = 40;

let Board;

let w = 480;
let h = 720;

function setup() {
    createCanvas(w, h);
    background(0, 0, 0);
    Board = new board(w, h);
    frameRate(5);
}

function draw() {
    background(0, 0, 0);
    //Board.press();
    Board.move();
    keyPressed();
    Board.show();
}

function keyPressed() {
    let bLength = Board.blocks.length;

    if (keyIsPressed === true) {
        if (keyCode === DOWN_ARROW) {
            Board.blocks[bLength - 1].increase();
        }
        if (keyCode === RIGHT_ARROW) {
            Board.blocks[bLength - 1].changeXPos(true);
        } else if (keyCode === LEFT_ARROW) {
            Board.blocks[bLength - 1].changeXPos(false);
        }
    }
}
